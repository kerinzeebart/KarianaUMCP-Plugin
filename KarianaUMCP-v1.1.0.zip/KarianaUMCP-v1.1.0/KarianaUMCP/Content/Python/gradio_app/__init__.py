# KarianaUMCP Gradio Web UI
# 6-tab dashboard for monitoring and control

__all__ = ['app', 'tabs']
